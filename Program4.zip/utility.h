#ifndef UTILITY_H
#define UTILITY_H
//Gives ANSI version of standard includes
#include <iostream>
#include <limits>
#include <cmath>
#include <cstdlib>
#include <cstddef>
#include <fstream>
#include <cctype>
#include <ctime>
#include <string>
#include <vector>
#include <map>
#include <algorithm> 
#include <queue>
#include <sstream>
#include <fstream>
#include <bitset>

using namespace std;

#endif //UTILITY_H